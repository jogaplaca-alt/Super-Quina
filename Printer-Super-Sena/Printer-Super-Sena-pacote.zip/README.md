# Printer Super Sena — GitHub Actions

Este pacote serve para importar o projeto recuperado em um repositório GitHub exclusivo do aplicativo de impressão.

## Importação
1. Crie um repositório vazio chamado `Printer-Super-Sena` na conta GitHub `superquina`.
2. Envie para a raiz do repositório os itens deste pacote: `source.zip`, a pasta `.github` e este `README.md`.
3. Faça o commit na branch principal do novo repositório.

O workflow inicia automaticamente após o commit ou pode ser iniciado em **Actions → Build Printer Super Sena APK → Run workflow**.

## Resultado
Quando a compilação passar, o APK ficará em **Actions → execução concluída → Artifacts → Printer-Super-Sena-debug**.

A primeira execução é também um teste de recuperação: o código vem do APK original descompilado e ainda pode apresentar incompatibilidades de compilação. Os erros serão corrigidos com base no log real do Actions.
